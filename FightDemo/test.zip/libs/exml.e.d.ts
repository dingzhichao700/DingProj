declare module skins{
	class ButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class CheckBoxSkin extends eui.Skin{
	}
}
declare module skins{
	class HScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class HSliderSkin extends eui.Skin{
	}
}
declare module skins{
	class ItemRendererSkin extends eui.Skin{
	}
}
declare module skins{
	class PanelSkin extends eui.Skin{
	}
}
declare module skins{
	class ProgressBarSkin extends eui.Skin{
	}
}
declare module skins{
	class RadioButtonSkin extends eui.Skin{
	}
}
declare module skins{
	class ScrollerSkin extends eui.Skin{
	}
}
declare module skins{
	class TextInputSkin extends eui.Skin{
	}
}
declare module skins{
	class ToggleSwitchSkin extends eui.Skin{
	}
}
declare module skins{
	class VScrollBarSkin extends eui.Skin{
	}
}
declare module skins{
	class VSliderSkin extends eui.Skin{
	}
}
declare class BackBtnSkin extends eui.Skin{
}
declare class BagItemSkin extends eui.Skin{
}
declare class bagView extends eui.Skin{
}
declare class CloseBtnSkin extends eui.Skin{
}
declare class BagBtnSkin extends eui.Skin{
}
declare class CreateRoleBtn extends eui.Skin{
}
declare class RandomNameBtn extends eui.Skin{
}
declare class AddBtnSkin extends eui.Skin{
}
declare class AddItemSkin extends eui.Skin{
}
declare class BarItemSkin extends eui.Skin{
}
declare class ItemAttrSkin extends eui.Skin{
}
declare class ItemDesSkin extends eui.Skin{
}
declare class ItemTipsBtn extends eui.Skin{
}
declare class ItemTipsSkin extends eui.Skin{
}
declare class CreateRole extends eui.Skin{
}
declare class SelectJobItem extends eui.Skin{
}
declare class GuidSkinView extends eui.Skin{
}
declare class LoadBarSkin extends eui.Skin{
}
declare class LoadViewSkin extends eui.Skin{
}
declare class SkillVMCSkin extends eui.Skin{
}
declare class WelcomViewSkin extends eui.Skin{
}
declare class CloseBtn extends eui.Skin{
}
declare class LoginBtn extends eui.Skin{
}
declare class loginInput extends eui.Skin{
}
declare class SelectBtn extends eui.Skin{
}
declare class SelectServer extends eui.Skin{
}
declare class SelectServerBtn extends eui.Skin{
}
declare class SelectServerItem extends eui.Skin{
}
declare class Server extends eui.Skin{
}
declare class TabBarItem extends eui.Skin{
}
declare class startBtn extends eui.Skin{
}
declare class MainBtn extends eui.Skin{
}
declare class MainUITabBarItem extends eui.Skin{
}
declare class MainUI extends eui.Skin{
}
declare class MissionItemSkin extends eui.Skin{
}
declare class MissionResultViewSkin extends eui.Skin{
}
declare class MissionViewSkin extends eui.Skin{
}
declare class PvpMatchItemSkin extends eui.Skin{
}
declare class PvpMatchItemSkin1 extends eui.Skin{
}
declare class PvpMatchViewSkin extends eui.Skin{
}
declare class TextInput extends eui.Skin{
}
declare class TipsItem extends eui.Skin{
}
declare class WeaponItemSkin extends eui.Skin{
}
declare class WeaponView1 extends eui.Skin{
}
declare class RoleItemSkin extends eui.Skin{
}
declare class WuHunItemSkin extends eui.Skin{
}
declare class WuhunView extends eui.Skin{
}
