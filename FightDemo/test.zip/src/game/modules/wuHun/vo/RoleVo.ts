class RoleVo {
	public name:string;
	public modelId:number;//1 2 3 4 5
	public lv:number;
	public activity:boolean;
	public score:number;

	public wuHunLv:number; // 0/1

	public itemId1:number;
	public itemId2:number;
	public itemId3:number;
	public itemId4:number;
	public itemId5:number;
	public itemId6:number;

	public open1:boolean;
	public open2:boolean;
	public open3:boolean;
	public open4:boolean;
	public open5:boolean;
	public open6:boolean;

	public attrHp:number;
	public attrAtk:number;
	public attrDef:number;
	public skillId:number;


	public constructor() {
	}
}