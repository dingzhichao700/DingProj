class WuhunItemInfo {
	public index:number;
	public source:string;
	public open:boolean;
	
	public constructor() {
	}
}