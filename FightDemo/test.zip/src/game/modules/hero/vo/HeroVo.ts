module game {
	export class HeroVo {
		public job: number;
		public id: number;
		public skills: Array<number>;
		public movieName: string;
		public attr: AttrData;
	}
}