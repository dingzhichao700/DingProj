class WeaponInfo {
	public name:string;
	public weaponId:number;
	public activity:boolean;
	public isNew:boolean;
	public attrHp:number;
	public attrAtk:number;
	public attrDef:number;
	public skillId:number;

	public constructor() {
	}
}