class FightInfo {
	public name:string;
	public sex:number;//1男 2女
	public lv:number;
	public pvpLv:number;
	public pvpTitle:string;
	
	public constructor() {
	}
}