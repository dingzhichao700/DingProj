
module egret {
    export class ItemConfig {
        
        public id:number = 0;
        public name:string = "";
        public quality:number = 0;
        
        public constructor() {
        }
    }
}
