class MissionVo {
	public missionId:number;
	public open:boolean;
	public pass:boolean;
	public constructor() {
	}
}