module game {
	export class CreateRoleItem {
		public constructor() {
		}
	}
}