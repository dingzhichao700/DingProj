module game {
	export class GAME_CORE {
		public static APP_WIDTH: number = 640;
		public static APP_HEIGHT: number = 960;
		
		public static SHOW_MAP_MOVIE: boolean = true;

		// public static init(stage: egret.Stage):void
		// {
		// let self = this;
		// self.stage = stage;

		// let date: Date = new Date();
		// self.clockMar.setCurrentTime(date.getTime());
		// date = null;
		
		// }
	}
}