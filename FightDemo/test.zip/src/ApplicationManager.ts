class ApplicationManager {
	public static CONTENT_W: number = 640;
	public static CONTENT_H: number = 960;
	/**游戏内容缩放比*/
	public static globalScale: number;

	public static topStage: egret.Sprite;

	public constructor() {
	}
}