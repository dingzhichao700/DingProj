var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var game;
(function (game) {
    var CreateRoleItem = (function () {
        function CreateRoleItem() {
        }
        return CreateRoleItem;
    }());
    game.CreateRoleItem = CreateRoleItem;
    __reflect(CreateRoleItem.prototype, "game.CreateRoleItem");
})(game || (game = {}));
//# sourceMappingURL=CreateRoleItem.js.map