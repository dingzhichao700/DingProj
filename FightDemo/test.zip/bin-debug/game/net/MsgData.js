var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var game;
(function (game) {
    var MsgData = (function () {
        function MsgData() {
        }
        return MsgData;
    }());
    game.MsgData = MsgData;
    __reflect(MsgData.prototype, "game.MsgData");
    var GLoginM = (function () {
        function GLoginM() {
        }
        return GLoginM;
    }());
    game.GLoginM = GLoginM;
    __reflect(GLoginM.prototype, "game.GLoginM");
    var GLoginForPlatformM = (function () {
        function GLoginForPlatformM() {
        }
        return GLoginForPlatformM;
    }());
    game.GLoginForPlatformM = GLoginForPlatformM;
    __reflect(GLoginForPlatformM.prototype, "game.GLoginForPlatformM");
    var GSelectCharacterM = (function () {
        function GSelectCharacterM() {
        }
        return GSelectCharacterM;
    }());
    game.GSelectCharacterM = GSelectCharacterM;
    __reflect(GSelectCharacterM.prototype, "game.GSelectCharacterM");
    var GCreateCharacterM = (function () {
        function GCreateCharacterM() {
        }
        return GCreateCharacterM;
    }());
    game.GCreateCharacterM = GCreateCharacterM;
    __reflect(GCreateCharacterM.prototype, "game.GCreateCharacterM");
    var GLoadFinishM = (function () {
        function GLoadFinishM() {
        }
        return GLoadFinishM;
    }());
    game.GLoadFinishM = GLoadFinishM;
    __reflect(GLoadFinishM.prototype, "game.GLoadFinishM");
})(game || (game = {}));
//# sourceMappingURL=MsgData.js.map