var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var ApplicationManager = (function () {
    function ApplicationManager() {
    }
    return ApplicationManager;
}());
ApplicationManager.CONTENT_W = 640;
ApplicationManager.CONTENT_H = 960;
__reflect(ApplicationManager.prototype, "ApplicationManager");
//# sourceMappingURL=ApplicationManager.js.map